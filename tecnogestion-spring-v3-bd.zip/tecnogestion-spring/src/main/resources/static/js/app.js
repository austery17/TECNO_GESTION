/* TecnoGestión — comportamiento compartido */
(function () {
    'use strict';
    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var money = function (n) {
        return Number(n).toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };
    window.tgMoney = money;

    /* Menú lateral en móvil */
    document.addEventListener('click', function (e) {
        if (e.target.closest('[data-sidebar-toggle]')) document.body.classList.toggle('sidebar-open');
        else if (e.target.closest('[data-sidebar-close]')) document.body.classList.remove('sidebar-open');
    });

    /* Fecha de hoy en la barra superior */
    document.querySelectorAll('[data-today]').forEach(function (el) {
        var d = new Date().toLocaleDateString('es-PE', { weekday: 'long', day: 'numeric', month: 'long' });
        el.textContent = d.charAt(0).toUpperCase() + d.slice(1);
    });

    /* Saludo según la hora */
    document.querySelectorAll('[data-greeting]').forEach(function (el) {
        var h = new Date().getHours();
        el.textContent = h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
    });

    /* Contadores animados en los indicadores */
    document.querySelectorAll('[data-countup]').forEach(function (el) {
        var target = parseFloat(el.getAttribute('data-countup')) || 0;
        var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
        var fmt = function (v) {
            return v.toLocaleString('es-PE', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
        };
        if (reduce || target === 0) { el.textContent = fmt(target); return; }
        var start = null, dur = 900;
        function step(ts) {
            if (start === null) start = ts;
            var p = Math.min((ts - start) / dur, 1);
            el.textContent = fmt(target * (1 - Math.pow(1 - p, 3)));
            if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
    });

    /* Búsqueda + filtro por categoría en tablas */
    document.querySelectorAll('[data-filter-table]').forEach(function (input) {
        var table = document.querySelector(input.getAttribute('data-filter-table'));
        if (!table) return;
        var rows = Array.prototype.slice.call(table.querySelectorAll('tbody tr[data-row]'));
        var none = table.querySelector('.no-results');
        var chips = document.querySelectorAll('[data-chip-for="' + input.getAttribute('data-filter-table') + '"] .chip');
        var activeCat = '';

        function apply() {
            var q = input.value.trim().toLowerCase(), visible = 0;
            rows.forEach(function (r) {
                var ok = r.textContent.toLowerCase().indexOf(q) !== -1 &&
                         (!activeCat || r.getAttribute('data-cat') === activeCat);
                r.style.display = ok ? '' : 'none';
                if (ok) visible++;
            });
            if (none) none.style.display = (visible === 0 && rows.length) ? 'table-row' : 'none';
        }
        input.addEventListener('input', apply);
        chips.forEach(function (c) {
            c.addEventListener('click', function () {
                chips.forEach(function (x) { x.classList.remove('is-active'); });
                c.classList.add('is-active');
                activeCat = c.getAttribute('data-cat') || '';
                apply();
            });
        });
    });

    /* Categorías dinámicas (productos) */
    document.querySelectorAll('[data-chip-for]').forEach(function (box) {
        var table = document.querySelector(box.getAttribute('data-chip-for'));
        if (!table) return;
        var cats = {};
        table.querySelectorAll('tbody tr[data-cat]').forEach(function (r) {
            var c = r.getAttribute('data-cat'); if (c) cats[c] = true;
        });
        Object.keys(cats).sort().forEach(function (c) {
            var b = document.createElement('button');
            b.type = 'button'; b.className = 'chip'; b.textContent = c; b.setAttribute('data-cat', c);
            box.appendChild(b);
        });
    });

    /* Modal de confirmación para eliminar */
    var confirmModalEl = document.getElementById('confirmModal');
    if (confirmModalEl) {
        confirmModalEl.addEventListener('show.bs.modal', function (ev) {
            var t = ev.relatedTarget; if (!t) return;
            confirmModalEl.querySelector('[data-confirm-title]').textContent = t.getAttribute('data-title') || '¿Eliminar este registro?';
            confirmModalEl.querySelector('[data-confirm-text]').textContent = t.getAttribute('data-text') || 'Esta acción no se puede deshacer.';
            confirmModalEl.querySelector('[data-confirm-go]').setAttribute('href', t.getAttribute('data-href'));
        });
    }

    /* Modales de alta: foco al abrir, limpiar al cerrar, abrir con #nuevo */
    var nuevo = document.getElementById('modalNuevo');
    if (nuevo) {
        nuevo.addEventListener('shown.bs.modal', function () {
            var f = nuevo.querySelector('input:not([type=hidden]), select'); if (f) f.focus();
        });
        nuevo.addEventListener('hidden.bs.modal', function () {
            var form = nuevo.querySelector('form'); if (form) { form.reset(); form.dispatchEvent(new Event('reset')); }
        });
        if (location.hash === '#nuevo') bootstrap.Modal.getOrCreateInstance(nuevo).show();
    }

    /* Calculadora de venta en vivo */
    var saleForm = document.getElementById('formVenta');
    if (saleForm) {
        var selP = saleForm.querySelector('[name=producto]'), qty = saleForm.querySelector('[name=cantidad]');
        var unit = document.getElementById('saleUnit'), tot = document.getElementById('saleTotal'),
            stockHint = document.getElementById('saleStock');
        var calc = function () {
            var o = selP.options[selP.selectedIndex];
            var price = o && o.getAttribute('data-precio') ? parseFloat(o.getAttribute('data-precio')) : 0;
            var q = parseInt(qty.value, 10) || 0;
            unit.textContent = 'S/ ' + money(price);
            tot.textContent = 'S/ ' + money(price * q);
            stockHint.textContent = o && o.getAttribute('data-stock') ? 'Stock disponible: ' + o.getAttribute('data-stock') + ' unidades' : 'Elige un producto para ver el stock.';
        };
        selP.addEventListener('change', calc); qty.addEventListener('input', calc);
        saleForm.addEventListener('reset', function () { setTimeout(calc, 0); });
        calc();
    }

    /* Botones con estado de carga al enviar */
    document.querySelectorAll('form[data-loading]').forEach(function (f) {
        f.addEventListener('submit', function () {
            var b = f.querySelector('[type=submit]');
            if (b) { b.disabled = true; b.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>' + (b.getAttribute('data-loading-text') || 'Procesando...'); }
        });
    });

    /* Mostrar/ocultar contraseña + credenciales de demo */
    var pw = document.getElementById('pw'), pwBtn = document.getElementById('pwToggle');
    if (pw && pwBtn) {
        pwBtn.addEventListener('click', function () {
            var show = pw.type === 'password'; pw.type = show ? 'text' : 'password';
            pwBtn.innerHTML = '<i class="bi ' + (show ? 'bi-eye-slash' : 'bi-eye') + '"></i>';
            pwBtn.setAttribute('aria-label', show ? 'Ocultar contraseña' : 'Mostrar contraseña');
        });
    }
    var demo = document.getElementById('demoFill');
    if (demo) demo.addEventListener('click', function () {
        document.getElementById('usr').value = 'admin'; document.getElementById('pw').value = 'admin123';
        document.getElementById('pw').focus();
    });

    /* Avisos tras guardar */
    if (window.bootstrap) document.querySelectorAll('.tg-toast').forEach(function (el) {
        bootstrap.Toast.getOrCreateInstance(el, { delay: 3800 }).show();
    });
})();
