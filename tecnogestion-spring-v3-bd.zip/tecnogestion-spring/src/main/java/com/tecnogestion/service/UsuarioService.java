package com.tecnogestion.service;

import com.tecnogestion.model.Usuario;
import com.tecnogestion.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

/**
 * Servicio de usuarios respaldado por base de datos (JPA).
 * Usuario de prueba: admin / admin123
 */
@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    public boolean validar(String usuario, String password) {
        return repository.findById(usuario)
                .map(u -> u.getPassword().equals(password))
                .orElse(false);
    }

    public Usuario buscarPorUsuario(String usuario) {
        return repository.findById(usuario).orElse(null);
    }
}
