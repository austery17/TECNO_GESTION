package com.tecnogestion.service;

import com.tecnogestion.model.Producto;
import com.tecnogestion.repository.ProductoRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio de productos respaldado por base de datos (JPA).
 */
@Service
public class ProductoService {

    private final ProductoRepository repository;

    public ProductoService(ProductoRepository repository) {
        this.repository = repository;
    }

    public List<Producto> listar() {
        return repository.findAll(Sort.by("id"));
    }

    public void agregar(Producto producto) {
        producto.setId(null);
        repository.save(producto);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
