package com.tecnogestion.service;

import com.tecnogestion.model.Cliente;
import com.tecnogestion.repository.ClienteRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio de clientes respaldado por base de datos (JPA).
 */
@Service
public class ClienteService {

    private final ClienteRepository repository;

    public ClienteService(ClienteRepository repository) {
        this.repository = repository;
    }

    public List<Cliente> listar() {
        return repository.findAll(Sort.by("id"));
    }

    public void agregar(Cliente cliente) {
        cliente.setId(null);
        repository.save(cliente);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
