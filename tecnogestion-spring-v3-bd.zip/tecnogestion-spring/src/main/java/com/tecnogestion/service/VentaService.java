package com.tecnogestion.service;

import com.tecnogestion.model.Venta;
import com.tecnogestion.repository.VentaRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * Servicio de ventas respaldado por base de datos (JPA).
 */
@Service
public class VentaService {

    private final VentaRepository repository;

    public VentaService(VentaRepository repository) {
        this.repository = repository;
    }

    public List<Venta> listar() {
        return repository.findAll(Sort.by("id"));
    }

    public void agregar(Venta venta) {
        venta.setId(null);
        venta.setFecha(LocalDate.now());
        repository.save(venta);
    }

    public void eliminar(Long id) {
        repository.deleteById(id);
    }
}
