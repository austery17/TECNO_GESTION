package com.tecnogestion.controller;

import com.tecnogestion.model.Venta;
import com.tecnogestion.service.ClienteService;
import com.tecnogestion.service.ProductoService;
import com.tecnogestion.service.VentaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Controller
@RequestMapping("/ventas")
public class VentaController {

    private final VentaService ventaService;
    private final ClienteService clienteService;
    private final ProductoService productoService;

    public VentaController(VentaService ventaService,
                            ClienteService clienteService,
                            ProductoService productoService) {
        this.ventaService = ventaService;
        this.clienteService = clienteService;
        this.productoService = productoService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        // Más recientes primero
        List<Venta> ventas = new ArrayList<>(ventaService.listar());
        Collections.reverse(ventas);

        double totalVendido = ventas.stream().mapToDouble(Venta::getTotal).sum();
        model.addAttribute("ventas", ventas);
        model.addAttribute("totalVendido", totalVendido);
        model.addAttribute("ticketPromedio", ventas.isEmpty() ? 0.0 : totalVendido / ventas.size());
        model.addAttribute("clientes", clienteService.listar());
        model.addAttribute("productos", productoService.listar());
        model.addAttribute("nuevaVenta", new Venta());
        return "ventas";
    }

    @PostMapping("/agregar")
    public String agregar(@ModelAttribute Venta nuevaVenta, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        double precioUnitario = productoService.listar().stream()
                .filter(p -> p.getNombre().equals(nuevaVenta.getProducto()))
                .findFirst()
                .map(p -> p.getPrecio())
                .orElse(0.0);
        nuevaVenta.setTotal(precioUnitario * nuevaVenta.getCantidad());
        ventaService.agregar(nuevaVenta);
        ra.addFlashAttribute("mensaje", "Venta registrada");
        return "redirect:/ventas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        ventaService.eliminar(id);
        ra.addFlashAttribute("mensaje", "Venta eliminada");
        return "redirect:/ventas";
    }
}
