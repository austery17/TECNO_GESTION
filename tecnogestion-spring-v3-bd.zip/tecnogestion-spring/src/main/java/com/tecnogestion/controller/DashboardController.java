package com.tecnogestion.controller;

import com.tecnogestion.model.Producto;
import com.tecnogestion.model.Venta;
import com.tecnogestion.service.ClienteService;
import com.tecnogestion.service.ProductoService;
import com.tecnogestion.service.VentaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class DashboardController {

    /** Un producto con menos unidades que este valor se considera con stock bajo. */
    public static final int STOCK_BAJO = 10;

    private final ClienteService clienteService;
    private final ProductoService productoService;
    private final VentaService ventaService;

    public DashboardController(ClienteService clienteService,
                                ProductoService productoService,
                                VentaService ventaService) {
        this.clienteService = clienteService;
        this.productoService = productoService;
        this.ventaService = ventaService;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        List<Venta> ventas = ventaService.listar();

        model.addAttribute("nombreUsuario", session.getAttribute("nombreUsuario"));
        model.addAttribute("totalClientes", clienteService.listar().size());
        model.addAttribute("totalProductos", productoService.listar().size());
        model.addAttribute("totalVentas", ventas.size());

        double totalIngresos = ventas.stream().mapToDouble(Venta::getTotal).sum();
        model.addAttribute("totalIngresos", totalIngresos);
        model.addAttribute("ticketPromedio", ventas.isEmpty() ? 0.0 : totalIngresos / ventas.size());

        // Últimas 5 ventas (la más reciente primero)
        List<Venta> recientes = new ArrayList<>(ventas);
        Collections.reverse(recientes);
        model.addAttribute("ventasRecientes", recientes.stream().limit(5).toList());

        // Productos con stock bajo
        List<Producto> stockBajo = productoService.listar().stream()
                .filter(p -> p.getStock() < STOCK_BAJO)
                .toList();
        model.addAttribute("stockBajo", stockBajo);

        // Datos para el gráfico: total vendido (S/) agrupado por producto
        Map<String, Double> ventasPorProducto = new LinkedHashMap<>();
        for (Venta v : ventas) {
            ventasPorProducto.merge(v.getProducto(), v.getTotal(), Double::sum);
        }
        model.addAttribute("chartLabels", ventasPorProducto.keySet());
        model.addAttribute("chartValues", ventasPorProducto.values());

        return "dashboard";
    }
}
