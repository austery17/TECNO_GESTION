package com.tecnogestion.controller;

import com.tecnogestion.model.Producto;
import com.tecnogestion.service.ProductoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        var productos = productoService.listar();
        model.addAttribute("productos", productos);
        model.addAttribute("nuevoProducto", new Producto());
        model.addAttribute("valorInventario",
                productos.stream().mapToDouble(p -> p.getPrecio() * p.getStock()).sum());
        model.addAttribute("stockBajoCount",
                productos.stream().filter(p -> p.getStock() < DashboardController.STOCK_BAJO).count());
        return "productos";
    }

    @PostMapping("/agregar")
    public String agregar(@ModelAttribute Producto nuevoProducto, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        productoService.agregar(nuevoProducto);
        ra.addFlashAttribute("mensaje", "Producto agregado");
        return "redirect:/productos";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session, RedirectAttributes ra) {
        if (session.getAttribute("usuarioActivo") == null) {
            return "redirect:/login";
        }
        productoService.eliminar(id);
        ra.addFlashAttribute("mensaje", "Producto eliminado");
        return "redirect:/productos";
    }
}
