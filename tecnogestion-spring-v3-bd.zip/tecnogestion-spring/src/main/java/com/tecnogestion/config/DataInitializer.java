package com.tecnogestion.config;

import com.tecnogestion.model.Cliente;
import com.tecnogestion.model.Producto;
import com.tecnogestion.model.Usuario;
import com.tecnogestion.model.Venta;
import com.tecnogestion.repository.ClienteRepository;
import com.tecnogestion.repository.ProductoRepository;
import com.tecnogestion.repository.UsuarioRepository;
import com.tecnogestion.repository.VentaRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;

/**
 * Carga datos iniciales solo si las tablas estan vacias.
 */
@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner cargarDatos(UsuarioRepository usuarios,
                                  ClienteRepository clientes,
                                  ProductoRepository productos,
                                  VentaRepository ventas) {
        return args -> {
            if (usuarios.count() == 0) {
                usuarios.save(new Usuario("admin", "admin123", "Administrador TecnoGestion"));
            }
            if (clientes.count() == 0) {
                clientes.save(new Cliente(null, "Comercial Los Andes S.R.L.", "20458796321", "987654321", "contacto@losandes.com"));
                clientes.save(new Cliente(null, "Inversiones del Norte E.I.R.L.", "20601122334", "956412378", "ventas@invnorte.com"));
            }
            if (productos.count() == 0) {
                productos.save(new Producto(null, "Laptop Core i5 16GB", "Equipos", 2899.90, 12));
                productos.save(new Producto(null, "Mouse inalambrico", "Accesorios", 39.90, 50));
                productos.save(new Producto(null, "Impresora multifuncional", "Equipos", 649.00, 8));
            }
            if (ventas.count() == 0) {
                LocalDate hoy = LocalDate.now();
                ventas.save(new Venta(null, "Comercial Los Andes S.R.L.", "Laptop Core i5 16GB", 2, 5799.80, hoy));
                ventas.save(new Venta(null, "Inversiones del Norte E.I.R.L.", "Mouse inalambrico", 5, 199.50, hoy));
                ventas.save(new Venta(null, "Comercial Los Andes S.R.L.", "Impresora multifuncional", 1, 649.00, hoy));
            }
        };
    }
}
